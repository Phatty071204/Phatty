// --- 1. PHẦN SẢN PHẨM & TÌM KIẾM ---
const products = [
    { id: 1, name: "Laptop Gaming ASUS", price: "20,000,000 VNĐ" },
    { id: 2, name: "Điện thoại iPhone 15", price: "22,000,000 VNĐ" },
    { id: 3, name: "Tai nghe Bluetooth Sony", price: "2,500,000 VNĐ" },
    { id: 4, name: "Bàn phím cơ Logitech", price: "1,800,000 VNĐ" },
    { id: 5, name: "Màn hình Dell UltraSharp", price: "6,500,000 VNĐ" }
];

function displayProducts(arr) {
    const container = document.getElementById("productContainer");
    const errorMsg = document.getElementById("errorMsg");
    if(!container) return;
    container.innerHTML = "";

    if (arr.length === 0) {
        errorMsg.style.display = "block";
        return;
    }
    errorMsg.style.display = "none";

    arr.forEach(p => {
        const item = document.createElement("div");
        item.className = "product-card";
        item.innerHTML = `<h3>${p.name}</h3><p>${p.price}</p>`;
        container.appendChild(item);
    });
}

displayProducts(products);

function searchProducts() {
    const query = document.getElementById("searchInput").value.toLowerCase().trim();
    const filtered = products.filter(p => p.name.toLowerCase().includes(query));
    displayProducts(filtered);
}

// --- 2. PHẦN ĐĂNG KÝ & LOCALSTORAGE ---
function handleRegister(event) {
    event.preventDefault();
    const name = document.getElementById("regName").value;
    const email = document.getElementById("regEmail").value;
    const password = document.getElementById("regPassword").value;
    const successMsg = document.getElementById("regSuccess");
    const errorMsg = document.getElementById("regError");

    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;

    if (!passwordRegex.test(password)) {
        errorMsg.style.display = "block";
        errorMsg.innerText = "Mật khẩu phải từ 8 ký tự trở lên, bao gồm chữ hoa, chữ thường và số!";
        successMsg.style.display = "none";
        return;
    }

    errorMsg.style.display = "none";
    const userData = { name, email, password: btoa(password) };
    localStorage.setItem("user_registered", JSON.stringify(userData));

    successMsg.style.display = "block";
    successMsg.innerText = "Đăng ký thành công! Dữ liệu đã được lưu vào LocalStorage.";
    document.getElementById("registerForm").reset();
}

// --- 3. PHẦN ĐỒNG HỒ ĐẾM NGƯỢC ---
let timerInterval = null;

function startCountdown() {
    if (timerInterval) clearInterval(timerInterval);

    let totalSeconds = 10 * 60;
    const timerDisplay = document.getElementById("countdownTimer");
    
    timerInterval = setInterval(() => {
        let minutes = Math.floor(totalSeconds / 60);
        let seconds = totalSeconds % 60;

        timerDisplay.innerText = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

        if (totalSeconds < 60) {
            timerDisplay.classList.add("warning-animation");
        }

        if (totalSeconds <= 0) {
            clearInterval(timerInterval);
            timerDisplay.classList.remove("warning-animation");
            document.getElementById("timeOutModal").style.display = "flex";
        }
        totalSeconds--;
    }, 1000);
}

function closeModal() {
    document.getElementById("timeOutModal").style.display = "none";
}
